package com.tn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebTinTuc1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
