package com.tn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebTinTucApplicationTests {

    @Test
    void contextLoads() {
    }

}
