package com.tn.controller;

import com.tn.entity.Account;
import com.tn.repository.AccountRepository;
import com.tn.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping("account")
public class AccountController {

    @Autowired
    private AccountRepository accountRepo;

    @Autowired
    private AccountService accountService;

    @GetMapping
    public String getAll(Model model) {
        List<Account> accounts = accountService.getAllData();
        System.out.println(accounts);
        System.out.println();
        model.addAttribute("listAccount", accounts);
        return "account-list";
    }


    @GetMapping("/")
    public String home(){
        return "HTML/home";
    }

    @GetMapping("/login")
    public String login(){
        return "HTML/login";
    }

    @GetMapping("/add")
    public String add() {
        return "account-add";
    }


    @GetMapping("/detele/{id}")
    public String deteleAccount(@PathVariable Integer id) {
        System.out.println(id);
        accountService.deteleAccount(id);
        return "redirect:/account";
    }

    @PostMapping("/update")
    public String save(@ModelAttribute Account account) {
        System.out.println(account);
//    public String save(@RequestParam String articleName,@RequestParam String description){
//        System.out.println(articleName);
//        System.out.println(description);
        accountRepo.save(account);
        return "redirect:/account";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Integer id, Model model) {
        Account account = accountService.getById(id);
        model.addAttribute("account", account);
        return "account-edit";
    }

}

//    @PostMapping("login/{userName}/passWord")
//    public String login(@RequestParam String userName,
//                        @RequestParam String passWord){
//        if (userName.equals("admin") && passWord.equals("123456")){
//            return "Đăng Nhập Thành Công";
//        }else {
//            return "Đăng Nhập Thất Bại";
//        }
//    }