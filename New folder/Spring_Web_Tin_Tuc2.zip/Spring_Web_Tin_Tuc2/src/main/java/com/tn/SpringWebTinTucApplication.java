package com.tn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebTinTucApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringWebTinTucApplication.class, args);
    }

}
