package com.tn.service;

public interface DepartmentService {

}
