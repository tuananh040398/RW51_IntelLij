package com.tn.service;

import com.tn.entity.Account;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface AccountService {
    List<Account> getAllData();

    Account getById(Integer id);

    void deteleAccount(@Param("id") Integer id);
}
