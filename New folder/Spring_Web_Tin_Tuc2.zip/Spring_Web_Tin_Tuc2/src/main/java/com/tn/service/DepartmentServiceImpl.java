package com.tn.service;

public class DepartmentServiceImpl {
}
