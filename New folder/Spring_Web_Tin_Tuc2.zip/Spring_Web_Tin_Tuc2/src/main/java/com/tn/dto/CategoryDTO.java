package com.tn.dto;


import lombok.Data;

@Data
public class CategoryDTO {
    private Integer id;

    private String categoryName;

    private String description;
}
