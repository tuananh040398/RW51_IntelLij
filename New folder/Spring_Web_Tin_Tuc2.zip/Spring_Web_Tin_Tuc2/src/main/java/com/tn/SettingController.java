package com.tn;

public class SettingController {
}
