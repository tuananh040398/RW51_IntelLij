package com.huytien;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalExamJavaAdvandeApplicationTests {

    @Test
    void contextLoads() {
    }

}
