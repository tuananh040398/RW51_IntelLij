package com.huytien;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalExamJavaAdvancedApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinalExamJavaAdvancedApplication.class, args);
    }

}
