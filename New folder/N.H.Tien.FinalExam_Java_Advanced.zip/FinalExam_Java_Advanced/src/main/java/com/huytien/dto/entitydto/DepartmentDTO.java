package com.huytien.dto.entitydto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DepartmentDTO {

    private Integer id;

    private String name;

}
